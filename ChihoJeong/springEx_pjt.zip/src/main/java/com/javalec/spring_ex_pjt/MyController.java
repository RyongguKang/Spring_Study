package com.javalec.spring_ex_pjt;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	
	//슬래시view로 들어오면 view페이지를 찾아가라
	@RequestMapping("/view")
	public String view() {
		
		return "view";
	}
	
	@RequestMapping("/content/contentView")
	public String contentView(Model model) {
		
		//jsp에서 model객체를 쓸 수 있다
		model.addAttribute("id", "abc123");
		
		return "content/contentView";
	}
}
